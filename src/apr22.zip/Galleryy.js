import Gallery from "react-photo-gallery";
function Photogallery(){

  const photos = [
  {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/1_title_2020_kia_optima.jpg',
    width: 4,
    height: 3
  },
   {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/2_2020_honda_civic.jpg',
    width: 4,
    height: 3
  },
   {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/3_2019_kia_cadenza.jpg',
    width: 4,
    height: 3
  },{
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/4_2020_vw_passat.jpg',
    width: 4,
    height: 3
  },
  {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/5_2020_subaru_legacy.jpg',
    width: 4,
    height: 3
  },
  {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/6_2020_toyota_corolla_hybrid.jpg',
    width: 4,
    height: 3
  },
    {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/1_title_2020_kia_optima.jpg',
    width: 4,
    height: 3
  },
   {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/2_2020_honda_civic.jpg',
    width: 4,
    height: 3
  },
   {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/3_2019_kia_cadenza.jpg',
    width: 4,
    height: 3
  },{
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/4_2020_vw_passat.jpg',
    width: 4,
    height: 3
  },
  {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/5_2020_subaru_legacy.jpg',
    width: 4,
    height: 3
  },
  {
    src: 'https://cars.usnews.com/pics/size/640x420/static/images/article/202002/128389/6_2020_toyota_corolla_hybrid.jpg',
    width: 4,
    height: 3
  }

  
];
  return(
    <div>
    <h1>CARS</h1>
    <Gallery photos={photos}/>
    </div>
    
    )
}
export default Photogallery